/**
 * Created by Leszek on 2018-04-12.
 */
public class SerializacjaSamochodu {

    public Samochod car;
}
